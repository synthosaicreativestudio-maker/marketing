# 🧪 Руководство по тестированию системы

## Шаг 1: Инициализация базы данных

```bash
# В папке проекта
python3.10 init_db.py
```

**Ожидаемый результат:**
```
Инициализация базы данных...
Используется БД: sqlite:///./db/appeals.db
✅ База данных успешно инициализирована!
Созданы таблицы:
  - appeals (обращения)
  - appeal_messages (сообщения)
  - specialist_responses (ответы специалистов)
```

**Проверка:**
```bash
ls -la db/appeals.db
# Должен появиться файл db/appeals.db
```

---

## Шаг 2: Запуск REST API

В **отдельном терминале**:

```bash
# Установите зависимости (если еще не установлены)
pip3.10 install --user fastapi uvicorn sqlalchemy pydantic

# Запустите API
cd /Users/verakoroleva/Desktop/marketingbot
python3.10 -m uvicorn api.main:app --host 0.0.0.0 --port 8000 --reload
```

**Ожидаемый результат:**
```
INFO:     Uvicorn running on http://0.0.0.0:8000 (Press CTRL+C to quit)
INFO:     Started reloader process
INFO:     Started server process
INFO:     Waiting for application startup.
INFO:     Application startup complete.
```

**Проверка:**
Откройте в браузере: http://localhost:8000/docs

Должна открыться документация Swagger API.

---

## Шаг 3: Настройка админ-панели

Откройте файл `admin/app.js` и проверьте строку:

```javascript
const API_BASE_URL = window.location.origin + '/api';
```

**Для локального тестирования** измените на:

```javascript
const API_BASE_URL = 'http://localhost:8000/api';
```

---

## Шаг 4: Запуск админ-панели

### Вариант A: Через PythonAnywhere (рекомендуется)

1. Загрузите папку `admin/` на сервер
2. Настройте Static files в PythonAnywhere:
   - Web → Static files
   - URL: `/admin/`
   - Directory: `/home/yourusername/marketingbot/admin/`
3. Откройте: `https://yourusername.pythonanywhere.com/admin/`

### Вариант B: Локально (простой способ)

```bash
# В папке admin/
cd admin
python3.10 -m http.server 8080
```

Откройте в браузере: http://localhost:8080

---

## Шаг 5: Тестирование авторизации

1. Откройте админ-панель в браузере
2. Введите:
   - **Логин:** `admin`
   - **Пароль:** `admin`
3. Нажмите "Войти"

**Ожидаемый результат:**
- Экран авторизации исчезает
- Появляется список обращений (пока пустой)

---

## Шаг 6: Создание тестового обращения

### Через API (для теста):

```bash
curl -X POST "http://localhost:8000/api/appeals/" \
  -H "Content-Type: application/json" \
  -d '{
    "telegram_id": 123456789,
    "partner_code": "TEST001",
    "phone": "+79991234567",
    "fio": "Тестовый Пользователь",
    "status": "новое"
  }'
```

Или через Swagger UI: http://localhost:8000/docs

1. Найдите endpoint `POST /api/appeals/`
2. Нажмите "Try it out"
3. Вставьте JSON выше
4. Нажмите "Execute"

### Добавление сообщения:

```bash
curl -X POST "http://localhost:8000/api/appeals/1/messages" \
  -H "Content-Type: application/json" \
  -d '{
    "message_type": "user",
    "message_text": "Привет, это тестовое сообщение!"
  }'
```

---

## Шаг 7: Проверка в админ-панели

1. Обновите страницу админ-панели (F5)
2. Должно появиться тестовое обращение
3. Кликните на него
4. Должны открыться детали с сообщением

---

## Шаг 8: Тест отправки ответа

1. В деталях обращения введите текст ответа
2. Нажмите "Отправить ответ"
3. Должно появиться сообщение об успехе
4. Ответ должен появиться в истории сообщений

---

## 🔍 Проверка работы БД

```bash
# Просмотр всех обращений
sqlite3 db/appeals.db "SELECT * FROM appeals;"

# Просмотр сообщений
sqlite3 db/appeals.db "SELECT * FROM appeal_messages;"
```

---

## ⚠️ Возможные проблемы

### 1. API не запускается
**Решение:** Проверьте, что все зависимости установлены:
```bash
pip3.10 install --user -r requirements.txt
```

### 2. CORS ошибки в браузере
**Решение:** В `api/main.py` уже настроен CORS для всех источников

### 3. Админ-панель не подключается к API
**Решение:** Проверьте `API_BASE_URL` в `admin/app.js`

### 4. База данных не создается
**Решение:** Убедитесь, что папка `db/` существует:
```bash
mkdir -p db
python3.10 init_db.py
```

---

## ✅ Чеклист проверки

- [ ] БД инициализирована (`db/appeals.db` существует)
- [ ] API запущен (http://localhost:8000/docs открывается)
- [ ] Админ-панель открывается в браузере
- [ ] Авторизация работает (логин/пароль)
- [ ] Список обращений отображается (даже если пустой)
- [ ] Можно создать тестовое обращение через API
- [ ] Тестовое обращение видно в админ-панели
- [ ] Можно открыть детали обращения
- [ ] Можно отправить ответ

---

**Готово!** Если все шаги выполнены успешно, система работает! 🎉
