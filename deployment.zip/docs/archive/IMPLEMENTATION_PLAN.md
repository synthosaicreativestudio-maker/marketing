# 📋 План Реализации: API для WebApp

**Цель:** Обеспечить загрузку реальных акций из Google Sheets в WebApp через REST API.

## 1. Backend (Flask)
Файл: `webhook_handler.py`

- [ ] **Импорт сервисов:** Добавить импорт `PromotionsAPI` и инициализацию.
- [ ] **CORS Headers:** Добавить функцию `after_request` для разрешения кросс-доменных запросов (чтобы WebApp мог обращаться к серверу).
- [ ] **Endpoint `/api/promotions`:**
    - Метод: `GET`
    - Логика: Вызов `promotions_api.get_promotions_json()`.
    - Ответ: JSON со списком акций.
    - Обработка ошибок: Возврат 500 при сбое Google Sheets.

## 2. Frontend (WebApp)
Файл: `menu.html`

- [ ] **Конфигурация:** Добавить переменную `API_BASE_URL` (по умолчанию пустая строка, так как WebApp и API на одном домене, или адрес PythonAnywhere).
- [ ] **Функция `loadPromotions`:**
    - Удалить логику `tg.sendData`.
    - Реализовать `fetch('/api/promotions')`.
    - Добавить обработку загрузки (Loading state) и ошибок.
- [ ] **Отображение:** Убедиться, что формат JSON от API совпадает с тем, что ожидает функция `displayPromotions`.

## 3. Верификация
- [ ] Запустить `webhook_handler.py` локально.
- [ ] Выполнить тестовый запрос: `curl http://localhost:5000/api/promotions`.
- [ ] Открыть `menu.html` в браузере и убедиться, что акции загружаются (даже без Telegram).

## ⚠️ Риски
- **Google Sheets API Limits:** Частые запросы могут упереться в лимиты Google.
    - *Меры:* Проверить `promotions_api.py` на наличие кэширования. Если нет — добавить простое кэширование в память (TTL 5 минут).

---
**Статус:** Ожидает утверждения.
