# Миграция с Google Sheets на базу данных и мини-приложение

## 📋 Обзор

Этот документ описывает план миграции системы консультирования и акций с Google Sheets на базу данных с REST API для мини-приложения.

## 🎯 Цели миграции

1. **Убрать зависимость от Google Sheets API** для обращений и акций
2. **Создать REST API** для мини-приложения консультантов
3. **Улучшить производительность** (нет лимитов API Google)
4. **Упростить управление данными** через веб-интерфейс
5. **Обеспечить масштабируемость** системы

## 🏗️ Архитектура решения

### Вариант 1: SQLite (для начала, проще)

```
┌─────────────────┐
│  Telegram Bot   │
│   (bot.py)      │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  REST API       │
│  (Flask/FastAPI)│
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│   SQLite DB     │
│  (database.db)  │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│  Mini App        │
│  (Web Interface) │
└─────────────────┘
```

### Вариант 2: PostgreSQL (для продакшена)

```
┌─────────────────┐
│  Telegram Bot   │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  REST API        │
│  (FastAPI)       │
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  PostgreSQL     │
│  (Cloud DB)      │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│  Mini App        │
│  (React/Vue)     │
└─────────────────┘
```

## 📊 Структура базы данных

### Таблица: `appeals` (Обращения)

```sql
CREATE TABLE appeals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    telegram_id INTEGER NOT NULL,
    partner_code TEXT,
    phone TEXT,
    fio TEXT,
    status TEXT NOT NULL DEFAULT 'новое',  -- новое, в_работе, решено, передано_специалисту
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_telegram_id (telegram_id),
    INDEX idx_status (status)
);
```

### Таблица: `appeal_messages` (Сообщения в обращении)

```sql
CREATE TABLE appeal_messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appeal_id INTEGER NOT NULL,
    message_type TEXT NOT NULL,  -- user, ai, specialist
    message_text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appeal_id) REFERENCES appeals(id) ON DELETE CASCADE,
    INDEX idx_appeal_id (appeal_id)
);
```

### Таблица: `specialist_responses` (Ответы специалистов)

```sql
CREATE TABLE specialist_responses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    appeal_id INTEGER NOT NULL,
    response_text TEXT NOT NULL,
    specialist_name TEXT,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (appeal_id) REFERENCES appeals(id) ON DELETE CASCADE,
    INDEX idx_appeal_id (appeal_id)
);
```

### Таблица: `promotions` (Акции)

```sql
CREATE TABLE promotions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'ожидает',  -- активна, ожидает, закончена
    start_date DATE,
    end_date DATE,
    release_date DATE,
    content TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_dates (start_date, end_date)
);
```

### Таблица: `promotion_notifications` (Уведомления об акциях)

```sql
CREATE TABLE promotion_notifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    promotion_id INTEGER NOT NULL,
    telegram_id INTEGER NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (promotion_id) REFERENCES promotions(id) ON DELETE CASCADE,
    UNIQUE(promotion_id, telegram_id),
    INDEX idx_telegram_id (telegram_id)
);
```

## 🔌 REST API Endpoints

### Обращения (Appeals)

```
GET    /api/appeals                    # Список всех обращений (с фильтрами)
GET    /api/appeals/{id}               # Детали обращения
GET    /api/appeals/user/{telegram_id} # Обращения пользователя
POST   /api/appeals                    # Создать обращение
PUT    /api/appeals/{id}/status        # Изменить статус
POST   /api/appeals/{id}/messages      # Добавить сообщение
GET    /api/appeals/{id}/messages       # История сообщений
POST   /api/appeals/{id}/response      # Ответ специалиста
```

### Акции (Promotions)

```
GET    /api/promotions                 # Список активных акций
GET    /api/promotions/{id}            # Детали акции
POST   /api/promotions                  # Создать акцию
PUT    /api/promotions/{id}             # Обновить акцию
DELETE /api/promotions/{id}             # Удалить акцию
GET    /api/promotions/active           # Только активные акции
```

### Статистика

```
GET    /api/stats/appeals               # Статистика по обращениям
GET    /api/stats/promotions            # Статистика по акциям
```

## 🛠️ Технологический стек

### Backend
- **FastAPI** или **Flask** - REST API
- **SQLAlchemy** - ORM для работы с БД
- **SQLite** (для начала) или **PostgreSQL** (для продакшена)
- **Alembic** - миграции БД

### Frontend (Mini App)
- **React** или **Vue.js** - фреймворк
- **Telegram WebApp SDK** - интеграция с Telegram
- **Axios/Fetch** - HTTP клиент

### Инфраструктура
- **PythonAnywhere** или **Heroku** - хостинг
- **GitHub Actions** - CI/CD (опционально)

## 📝 План миграции

### Этап 1: Подготовка (1-2 дня)

1. ✅ Создать структуру БД (SQLAlchemy models)
2. ✅ Настроить миграции (Alembic)
3. ✅ Создать скрипт миграции данных из Google Sheets
4. ✅ Настроить тестовую БД

### Этап 2: REST API (3-5 дней)

1. ✅ Создать FastAPI/Flask приложение
2. ✅ Реализовать endpoints для обращений
3. ✅ Реализовать endpoints для акций
4. ✅ Добавить аутентификацию (JWT или API ключи)
5. ✅ Написать тесты

### Этап 3: Миграция сервисов (2-3 дня)

1. ✅ Создать `AppealsServiceDB` (замена `AppealsService`)
2. ✅ Создать `PromotionsServiceDB` (замена `PromotionsService`)
3. ✅ Обновить `bot.py` для использования новых сервисов
4. ✅ Обновить `handlers.py`
5. ✅ Обновить `response_monitor.py`

### Этап 4: Мини-приложение (3-5 дней)

1. ✅ Создать React/Vue приложение
2. ✅ Интегрировать с Telegram WebApp SDK
3. ✅ Реализовать интерфейс для консультантов
4. ✅ Реализовать интерфейс для управления акциями
5. ✅ Добавить фильтры и поиск

### Этап 5: Миграция данных (1 день)

1. ✅ Экспорт данных из Google Sheets
2. ✅ Импорт в БД
3. ✅ Валидация данных
4. ✅ Резервное копирование

### Этап 6: Тестирование и деплой (2-3 дня)

1. ✅ Тестирование на staging
2. ✅ Исправление багов
3. ✅ Деплой на продакшен
4. ✅ Мониторинг

## 🔄 Миграция данных из Google Sheets

### Скрипт миграции обращений

```python
# migrate_appeals.py
import sqlite3
import gspread
from datetime import datetime

def migrate_appeals():
    # 1. Подключение к Google Sheets
    # 2. Чтение всех обращений
    # 3. Парсинг данных
    # 4. Вставка в БД
    pass
```

### Скрипт миграции акций

```python
# migrate_promotions.py
def migrate_promotions():
    # 1. Подключение к Google Sheets
    # 2. Чтение всех акций
    # 3. Парсинг данных
    # 4. Вставка в БД
    pass
```

## 🔐 Аутентификация и безопасность

### Для REST API

1. **JWT токены** для консультантов
2. **API ключи** для бота
3. **Rate limiting** для защиты от DDoS
4. **CORS** настройки для мини-приложения

### Для мини-приложения

1. **Telegram WebApp.initData** - проверка подлинности
2. **HTTPS** обязательно
3. **Валидация данных** на клиенте и сервере

## 📈 Преимущества новой архитектуры

1. ✅ **Производительность**: Нет лимитов Google Sheets API
2. ✅ **Масштабируемость**: Легко добавить новые функции
3. ✅ **Гибкость**: Полный контроль над данными
4. ✅ **Безопасность**: Собственная система аутентификации
5. ✅ **Аналитика**: Легко делать запросы и отчеты
6. ✅ **Офлайн работа**: Возможность кэширования

## ⚠️ Риски и митигация

### Риск 1: Потеря данных при миграции
**Митигация**: Полное резервное копирование перед миграцией

### Риск 2: Простой системы
**Митигация**: Постепенная миграция, возможность отката

### Риск 3: Проблемы с производительностью
**Митигация**: Тестирование на staging, мониторинг

## 🚀 Быстрый старт

### 1. Установка зависимостей

```bash
pip install fastapi uvicorn sqlalchemy alembic
```

### 2. Создание БД

```bash
alembic init alembic
alembic revision --autogenerate -m "Initial migration"
alembic upgrade head
```

### 3. Запуск API

```bash
uvicorn api.main:app --host 0.0.0.0 --port 8000
```

## 📚 Дополнительные ресурсы

- [FastAPI Documentation](https://fastapi.tiangolo.com/)
- [SQLAlchemy Documentation](https://docs.sqlalchemy.org/)
- [Telegram WebApp SDK](https://core.telegram.org/bots/webapps)

## 📝 Следующие шаги

1. Выбрать технологический стек (FastAPI + SQLite или PostgreSQL)
2. Создать структуру проекта
3. Начать с миграции обращений
4. Затем мигрировать акции
5. Создать мини-приложение

---

**Версия**: 1.0  
**Дата**: 2026-01-05  
**Автор**: Migration Plan
