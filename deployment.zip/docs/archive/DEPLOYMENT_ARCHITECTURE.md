# 🏗️ Архитектура деплоя: GitHub vs PythonAnywhere

## 📍 Где что находится

### 🔵 GitHub (Хранилище кода)

**Что хранится:**
- ✅ Весь исходный код проекта
- ✅ Файлы конфигурации (кроме `.env` - он в `.gitignore`)
- ✅ Документация
- ✅ История изменений (git)

**Что НЕ хранится:**
- ❌ База данных (файлы `.db`)
- ❌ Секретные ключи (`.env` файл)
- ❌ Логи (`*.log`)
- ❌ Кэш (`__pycache__/`)

**Структура на GitHub:**
```
marketingbot/
├── bot.py
├── handlers.py
├── db/
│   ├── models.py
│   └── database.py
├── api/
│   └── main.py
├── requirements.txt
├── README.md
└── ...
```

---

### 🟢 PythonAnywhere (Сервер - где все работает)

**Что находится и работает:**

#### 1. **Бот (bot.py)**
- Запускается как фоновый процесс
- Работает 24/7
- Путь: `/home/yourusername/marketing/bot.py`

#### 2. **REST API (FastAPI)**
- Запускается через Web App в PythonAnywhere
- Доступен по адресу: `https://yourusername.pythonanywhere.com`
- Путь: `/home/yourusername/marketing/api/main.py`

#### 3. **База данных (SQLite)**
- Файл: `/home/yourusername/marketing/db/appeals.db`
- Создается автоматически при первом запуске
- **ВАЖНО**: Этот файл НЕ коммитится в GitHub (в `.gitignore`)

#### 4. **Мини-приложение (HTML/JS)**
- Вариант A: На PythonAnywhere (в папке `static/`)
- Вариант B: На GitHub Pages (отдельный репозиторий)
- Вариант C: На отдельном хостинге

#### 5. **Переменные окружения (.env)**
- Файл: `/home/yourusername/marketing/.env`
- Содержит секретные ключи
- **НЕ коммитится в GitHub**

---

## 🔄 Процесс деплоя

### Шаг 1: Разработка (локально)
```bash
# На вашем компьютере
git add .
git commit -m "Добавлена БД для обращений"
git push origin main
```

### Шаг 2: Деплой на PythonAnywhere
```bash
# На PythonAnywhere через консоль
cd ~/marketing
git pull origin main
pip3.10 install --user -r requirements.txt
python3.10 init_db.py  # Создать БД, если еще нет
pkill -f "python.*bot.py"
nohup python3.10 bot.py > bot.log 2>&1 &
```

### Шаг 3: Обновление Web App
- В панели PythonAnywhere → Web → Reload

---

## 📂 Структура файлов на PythonAnywhere

```
/home/yourusername/marketing/
├── bot.py                    # Основной бот
├── handlers.py               # Обработчики команд
├── .env                      # Секретные ключи (НЕ в git)
├── bot.log                   # Логи бота (НЕ в git)
│
├── db/
│   ├── appeals.db           # База данных SQLite (НЕ в git)
│   ├── models.py            # Модели SQLAlchemy
│   └── database.py           # Подключение к БД
│
├── api/
│   ├── main.py              # FastAPI приложение
│   ├── routers/
│   │   └── appeals.py       # API endpoints
│   └── services/
│       └── appeals_db.py    # Сервис для работы с БД
│
├── miniapp/                  # Мини-приложение для консультантов
│   ├── index.html
│   ├── app.js
│   └── styles.css
│
└── requirements.txt         # Зависимости
```

---

## 🗄️ База данных: где и как

### SQLite (по умолчанию)

**Расположение:**
- Файл: `/home/yourusername/marketing/db/appeals.db`
- Создается автоматически при первом запуске `init_db.py`

**Преимущества:**
- ✅ Простота (один файл)
- ✅ Не требует отдельного сервера
- ✅ Бесплатно на PythonAnywhere

**Недостатки:**
- ⚠️ Ограничения при высокой нагрузке
- ⚠️ Нет одновременного доступа из нескольких процессов (для продакшена лучше PostgreSQL)

### PostgreSQL (для продакшена)

**Расположение:**
- Внешний сервис (например, ElephantSQL, Heroku Postgres)
- Или на отдельном сервере

**Настройка:**
```bash
# В .env
DATABASE_URL=postgresql://user:password@host:5432/dbname
```

---

## 🌐 Мини-приложение: варианты размещения

### Вариант 1: PythonAnywhere (рекомендуется для начала)

**Структура:**
```
/home/yourusername/marketing/miniapp/
├── index.html
├── app.js
└── styles.css
```

**Настройка в PythonAnywhere:**
1. Web → Static files
2. Добавить mapping: `/miniapp/` → `/home/yourusername/marketing/miniapp/`
3. URL: `https://yourusername.pythonanywhere.com/miniapp/index.html`

**Преимущества:**
- ✅ Все в одном месте
- ✅ Простая настройка
- ✅ HTTPS автоматически

### Вариант 2: GitHub Pages

**Структура:**
- Отдельный репозиторий или ветка `gh-pages`
- URL: `https://yourusername.github.io/marketing-miniapp/`

**Преимущества:**
- ✅ Бесплатно
- ✅ CDN от GitHub
- ✅ Отдельно от основного проекта

### Вариант 3: Отдельный хостинг

- Netlify, Vercel, или другой статический хостинг

---

## 🔐 Безопасность и секреты

### Что НЕ коммитится в GitHub:

1. **`.env` файл** - содержит все секреты
   ```bash
   # В .gitignore
   .env
   ```

2. **База данных** - файлы `.db`
   ```bash
   # В .gitignore
   *.db
   db/*.db
   ```

3. **Логи** - файлы `.log`
   ```bash
   # В .gitignore
   *.log
   ```

### Где хранить секреты на PythonAnywhere:

1. **В `.env` файле** (локально на сервере)
2. **В переменных окружения PythonAnywhere** (Web → Environment variables)
3. **В отдельном файле** (не в git)

---

## 📊 Схема работы системы

```
┌─────────────────┐
│   GitHub        │
│   (Код)         │
└────────┬────────┘
         │ git pull
         ▼
┌─────────────────┐
│ PythonAnywhere  │
│                 │
│  ┌───────────┐  │
│  │  bot.py   │  │ ← Telegram Bot
│  └─────┬─────┘  │
│        │        │
│  ┌─────▼─────┐  │
│  │ REST API  │  │ ← FastAPI (Web App)
│  └─────┬─────┘  │
│        │        │
│  ┌─────▼─────┐  │
│  │   БД      │  │ ← SQLite (appeals.db)
│  │ (SQLite)  │  │
│  └───────────┘  │
│                 │
│  ┌───────────┐  │
│  │ miniapp/  │  │ ← Мини-приложение
│  └───────────┘  │
└─────────────────┘
         │
         ▼
┌─────────────────┐
│   Пользователи  │
│  (Telegram)     │
└─────────────────┘
```

---

## 🚀 Быстрый чеклист деплоя

### Первый раз:

- [ ] Клонировать репозиторий на PythonAnywhere
- [ ] Установить зависимости (`pip install -r requirements.txt`)
- [ ] Создать `.env` файл с секретами
- [ ] Инициализировать БД (`python3.10 init_db.py`)
- [ ] Запустить бота (`python3.10 bot.py`)
- [ ] Настроить Web App для REST API
- [ ] Настроить Static files для мини-приложения

### Обновление:

- [ ] `git pull origin main` на PythonAnywhere
- [ ] `pip3.10 install --user -r requirements.txt` (если новые зависимости)
- [ ] Перезапустить бота
- [ ] Reload Web App

---

## 📝 Переменные окружения

### На PythonAnywhere (в `.env`):

```bash
# Telegram
TELEGRAM_TOKEN=your_token

# OpenAI
OPENAI_API_KEY=your_key
OPENAI_ASSISTANT_ID=your_id

# База данных
DATABASE_URL=sqlite:///./db/appeals.db
# или для PostgreSQL:
# DATABASE_URL=postgresql://user:pass@host:5432/db

# API
API_URL=https://yourusername.pythonanywhere.com
API_KEY=your_secret_key

# WebApp
WEB_APP_URL=https://yourusername.pythonanywhere.com/miniapp/
```

---

## ⚠️ Важные моменты

1. **База данных НЕ синхронизируется через git**
   - Резервное копирование вручную
   - Использовать `mysqldump` или экспорт SQLite

2. **`.env` файл НЕ в git**
   - Создавать вручную на каждом сервере
   - Или использовать переменные окружения PythonAnywhere

3. **Логи остаются на сервере**
   - Просматривать через `tail -f bot.log`
   - Или через панель PythonAnywhere

4. **Мини-приложение может быть отдельно**
   - Не обязательно на том же сервере
   - Главное - правильный URL в настройках

---

## 🔄 Резервное копирование

### База данных:

```bash
# SQLite
cp ~/marketing/db/appeals.db ~/backups/appeals_$(date +%Y%m%d).db

# Или экспорт в SQL
sqlite3 ~/marketing/db/appeals.db .dump > ~/backups/appeals_$(date +%Y%m%d).sql
```

### Код:

```bash
# Все уже в GitHub - это и есть резервная копия кода
```

---

**Итого:**
- **GitHub** = хранилище кода
- **PythonAnywhere** = сервер, где все работает (бот, API, БД, мини-приложение)
