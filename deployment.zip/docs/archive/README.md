# 📚 Документация MarketingBot

Добро пожаловать в документацию MarketingBot — профессионального Telegram-бота для маркетинга с веб-авторизацией, ИИ-ассистентом и интеграцией с Google Sheets.

## 📖 Содержание

### 🚀 Быстрый старт
- [Установка и настройка](getting-started/INSTALLATION.md) — Полная инструкция по установке
- [Быстрая настройка Google Apps Script](getting-started/QUICK_START_GOOGLE_APPS_SCRIPT.md) — Настройка API для акций

### 🏗️ Архитектура и дизайн
- [Архитектура системы](ARCHITECTURE.md) — Обзор архитектуры проекта
- [План дизайна](DESIGN_PLAN.md) — Дизайн-документ проекта
- [Функции системы](FEATURES.md) — Описание всех функций

### 🚢 Развертывание
- [Развертывание на Yandex Cloud](deployment/DEPLOYMENT_YANDEX.md) — Полное руководство
- [Развертывание на PythonAnywhere](deployment/DEPLOYMENT_PYTHONANYWHERE.md) — Альтернативный вариант
- [Архитектура развертывания](DEPLOYMENT_ARCHITECTURE.md) — Детали инфраструктуры

### 🔧 Руководства
- [Настройка Google Sheets](guides/GOOGLE_SHEETS.md) — Работа с Google Sheets
- [Настройка Google Apps Script](guides/GOOGLE_APPS_SCRIPT_SETUP.md) — API для акций
- [Настройка базы данных](DATABASE_SETUP.md) — Работа с SQLite
- [Миграция на базу данных](MIGRATION_TO_DATABASE.md) — Переход с Google Sheets

### 📡 API и интеграции
- [Справочник API](reference/API_REFERENCE.md) — Документация REST API
- [Интеграция с Google Sheets](guides/GOOGLE_SHEETS.md) — Детали интеграции

### 🐛 Решение проблем
- [Общее руководство по устранению неполадок](troubleshooting/TROUBLESHOOTING.md) — Решение типичных проблем
- [Проблемы с акциями](troubleshooting/PROMOTIONS_ISSUES.md) — Решение проблем с акциями
- [Проблемы с развертыванием](troubleshooting/DEPLOYMENT_ISSUES.md) — Проблемы при развертывании

### 🔒 Безопасность
- [Безопасность](SECURITY.md) — Рекомендации по безопасности

### 🧪 Тестирование
- [Руководство по тестированию](TESTING.md) — Как тестировать систему

### 📝 История изменений
- [Changelog](CHANGELOG.md) — История всех изменений проекта

## 🗺️ Навигация по документации

### Для новых пользователей
1. Начните с [Установки и настройки](getting-started/INSTALLATION.md)
2. Прочитайте [Архитектуру системы](ARCHITECTURE.md)
3. Изучите [Функции системы](FEATURES.md)

### Для разработчиков
1. [Архитектура системы](ARCHITECTURE.md)
2. [Справочник API](reference/API_REFERENCE.md)
3. [Руководство по тестированию](TESTING.md)

### Для администраторов
1. [Развертывание на Yandex Cloud](deployment/DEPLOYMENT_YANDEX.md)
2. [Настройка Cloudflare Tunnel](deployment/CLOUDFLARE_TUNNEL_SETUP.md)
3. [Решение проблем](troubleshooting/TROUBLESHOOTING.md)

## 📞 Поддержка

Если вы столкнулись с проблемой, которая не описана в документации:
1. Проверьте [Руководство по устранению неполадок](troubleshooting/TROUBLESHOOTING.md)
2. Изучите [Changelog](CHANGELOG.md) на предмет известных проблем
3. Создайте issue в репозитории проекта
