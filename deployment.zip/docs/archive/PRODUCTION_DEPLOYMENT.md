# 🛡️ Инструкция по развертыванию и мониторингу стабильного бота

## ✅ Выполненные исправления (коммит 418ccda)

Все критичные проблемы исправлены. Бот готов к круглосуточной работе.

---

## 🚀 Быстрый старт

### 1. Обновление кода на сервере

```bash
# Перейти в директорию проекта
cd /path/to/marketingbot

# Получить последние изменения
git pull origin main

# Установить обновлённые зависимости (SQLite компоненты удалены)
pip install -r requirements.txt
```

### 2. Локальное тестирование

```bash
# Запуск бота
python3 bot.py
```

**Проверка graceful shutdown:**
1. Подождите 1-2 минуты (пока запустятся все мониторинги)
2. Нажмите `Ctrl+C`
3. В логах должно появиться:
   ```
   Остановка всех мониторингов...
   Мониторинг здоровья бота остановлен
   Мониторинг ответов остановлен
   Мониторинг акций остановлен  ← ✅ НОВОЕ!
   Graceful shutdown завершен
   ```

**Что проверить:**
- ✅ Бот запускается без ошибок
- ✅ Все 3 мониторинга запускаются (здоровье, ответы, акции)
- ✅ При Ctrl+C все мониторинги корректно останавливаются
- ✅ Нет зависших процессов

---

## 🏭 Развертывание на production

### Вариант A: Systemd (рекомендуется для Linux)

**1. Создать systemd service:**

```bash
sudo nano /etc/systemd/system/marketingbot.service
```

```ini
[Unit]
Description=MarketingBot - Telegram Bot
After=network.target

[Service]
Type=simple
User=YOUR_USERNAME
WorkingDirectory=/path/to/marketingbot
Environment="PATH=/path/to/marketingbot/.venv/bin:/usr/local/bin:/usr/bin:/bin"
ExecStart=/path/to/marketingbot/.venv/bin/python bot.py
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

# Ограничения ресурсов (опционально)
MemoryLimit=512M
CPUQuota=50%

[Install]
WantedBy=multi-user.target
```

**2. Включить и запустить:**

```bash
sudo systemctl daemon-reload
sudo systemctl enable marketingbot.service
sudo systemctl start marketingbot.service
```

**3. Проверить статус:**

```bash
sudo systemctl status marketingbot.service
```

**4. Просмотр логов:**

```bash
# Все логи
sudo journalctl -u marketingbot.service

# Последние 100 строк
sudo journalctl -u marketingbot.service -n 100

# Логи в реальном времени
sudo journalctl -u marketingbot.service -f

# Логи с фильтром
sudo journalctl -u marketingbot.service | grep -E "(стабильность|ошибка|мониторинг)"
```

---

### Вариант B: Screen/tmux (для простого деплоя)

```bash
# Создать screen сессию
screen -S marketingbot

# Запустить бота
python3 bot.py

# Отключиться: Ctrl+A, затем D
# Вернуться: screen -r marketingbot
```

---

### Вариант C: PythonAnywhere (облачный хостинг)

См. документацию в `docs/DEPLOYMENT.md`

---

## 📊 Мониторинг стабильности

### Ключевые метрики

**1. Uptime (время безотказной работы):**
```bash
sudo systemctl status marketingbot.service | grep Active
```
Ожидаемый результат: `Active: active (running) since ...`

**2. Количество перезапусков:**
```bash
sudo journalctl -u marketingbot.service | grep "Бот завершил работу" | wc -l
```
Ожидаемый результат: 0-1 (после первого запуска)

**3. Ошибки за последний час:**
```bash
sudo journalctl -u marketingbot.service -p err --since "1 hour ago"
```
Ожидаемый результат: No entries (нет ошибок)

**4. Работа мониторингов:**
```bash
sudo journalctl -u marketingbot.service | grep "запущен"
```
Ожидаемый результат:
```
Мониторинг здоровья запущен
Мониторинг ответов запущен (проверка каждую минуту)
Мониторинг акций запущен (проверка каждые 15 минут)
```

**5. Graceful shutdown (при перезапуске):**
```bash
sudo journalctl -u marketingbot.service | grep "остановлен"
```
Ожидаемый результат:
```
Мониторинг здоровья бота остановлен
Мониторинг ответов остановлен
Мониторинг акций остановлен
```

---

## 🔍 Диагностика проблем

### Проблема: Бот часто перезапускается

**Причины:**
1. Сетевые проблемы (нет интернета)
2. Недействительные токены (TELEGRAM_TOKEN, OPENAI_API_KEY)
3. Проблемы с Google Sheets API

**Диагностика:**
```bash
# Проверить последние ошибки
sudo journalctl -u marketingbot.service -p err -n 50

# Проверить конфигурацию
cat .env | grep -E "TELEGRAM_TOKEN|OPENAI_API_KEY|SHEET_ID"
```

**Решение:**
1. Проверить подключение к интернету
2. Проверить валидность токенов
3. Проверить доступ к Google Sheets API

---

### Проблема: Мониторинг не запускается

**Диагностика:**
```bash
sudo journalctl -u marketingbot.service | grep -i "monitoring\|мониторинг"
```

**Ожидаемый результат:**
```
Инициализация ResponseMonitor...
ResponseMonitor готов к работе
Инициализация PromotionsNotifier с Gateway...
PromotionsNotifier готов к работе
Инициализация BotHealthMonitor...
BotHealthMonitor готов к работе
Мониторинг здоровья запущен
Мониторинг ответов запущен (проверка каждую минуту)
Мониторинг акций запущен (проверка каждые 15 минут)
```

**Решение:** Проверить наличие листов в Google Sheets

---

### Проблема: Бот не останавливается при Ctrl+C

**Это исправлено в коммите 418ccda!**

Если проблема всё ещё есть:
```bash
# Принудительная остановка
pkill -9 -f "python.*bot.py"

# Или через systemd
sudo systemctl stop marketingbot.service
```

---

## 📈 Оптимизация производительности

### Рекомендации

**1. Настроить интервалы мониторинга:**

В `bot.py`, строки 210, 219:
```python
# Для высокой нагрузки - увеличить интервалы
asyncio.create_task(response_monitor.start_monitoring(interval_seconds=120))  # 2 минуты
asyncio.create_task(promotions_notifier.start_monitoring(interval_minutes=30))  # 30 минут

# Для низкой нагрузки - уменьшить
asyncio.create_task(response_monitor.start_monitoring(interval_seconds=30))  # 30 секунд
asyncio.create_task(promotions_notifier.start_monitoring(interval_minutes=10))  # 10 минут
```

**2. Настроить кэширование:**

В `auth_service.py`, строка 27:
```python
# Увеличить TTL кэша для уменьшения нагрузки на Google Sheets
self._cache = TTLCache(maxsize=1000, ttl=600)  # 10 минут вместо 5
```

**3. Ограничить потребление ресурсов:**

В systemd service добавить:
```ini
MemoryLimit=512M
CPUQuota=50%
```

---

## 🎯 Чек-лист готовности к production

### Перед деплоем:

- [ ] ✅ Получены последние изменения с GitHub (`git pull`)
- [ ] ✅ Установлены обновлённые зависимости (`pip install -r requirements.txt`)
- [ ] ✅ Проверен `.env` файл (все токены валидны)
- [ ] ✅ Проверен доступ к Google Sheets
- [ ] ✅ Протестирован graceful shutdown локально (Ctrl+C)
- [ ] ✅ Настроен systemd service (для Linux)
- [ ] ✅ Настроены логи (journalctl или файлы)

### После деплоя:

- [ ] ✅ Бот запущен и работает (`systemctl status`)
- [ ] ✅ Все 3 мониторинга запустились (проверить логи)
- [ ] ✅ Отправлено тестовое сообщение боту
- [ ] ✅ Проверена авторизация через WebApp
- [ ] ✅ Создано тестовое обращение
- [ ] ✅ Просмотр акций работает
- [ ] ✅ Мониторинг работает 24 часа без падений

---

## 🆘 Горячая линия поддержки

### Команды для быстрой диагностики

```bash
# Статус бота
sudo systemctl status marketingbot.service

# Последние 50 логов
sudo journalctl -u marketingbot.service -n 50

# Логи в реальном времени
sudo journalctl -u marketingbot.service -f

# Перезапуск бота
sudo systemctl restart marketingbot.service

# Остановка бота
sudo systemctl stop marketingbot.service

# Запуск бота
sudo systemctl start marketingbot.service

# Проверка потребления ресурсов
ps aux | grep bot.py
top -p $(pgrep -f bot.py)

# Проверка слушающих портов (если есть webhook)
sudo netstat -tulpn | grep python
```

---

## 📝 Контакты и поддержка

**Документация:**
- `docs/DEPLOYMENT.md` - подробная инструкция по развертыванию
- `docs/COMPREHENSIVE_STABILITY_FIX.md` - детали исправлений стабильности
- `docs/TROUBLESHOOTING.md` - устранение проблем

**Git:**
- Последний коммит: `418ccda`
- Ветка: `main`
- Репозиторий: https://github.com/synthosaicreativestudio-maker/marketing

---

**Дата создания:** 2026-01-16  
**Версия:** 1.0  
**Автор:** Antigravity AI
