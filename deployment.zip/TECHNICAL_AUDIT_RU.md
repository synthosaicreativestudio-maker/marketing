# 📑 Технический Аудит: Система Креативного Маркетинга (Gemini 3 Pro)

Этот документ содержит архитектурный анализ, исходные коды ключевых компонентов и логи работы после миграции на Gemini 3.

> [!IMPORTANT]
> Все API-ключи, токены и приватные данные скрыты (заменены на `СКРЫТО`).

---

## 1. Архитектура ИИ (Gemini 3 Pro)
**Файл:** [gemini_service.py](file:///Users/verakoroleva/Desktop/marketingbot/gemini_service.py)

### Ключевые изменения:
*   **Инъекция Контекста (Context Injection):** Реализована через передачу системного промпта как первого сообщения от `user` с последующим подтверждением от `model`. Это гарантирует, что Gemini 3 Pro "принимает роль" до начала диалога.
*   **Управление Историей:** Метод `_add_to_history` сохраняет системный контекст (первые 2 сообщения) и обрезает только последующий диалог при превышении лимита (10 сообщений).
*   **Безопасность:** Отключены фильтры `safety_settings` (`BLOCK_NONE`) для предотвращения ложной цензуры ответов по маркетингу.

### Исходный код (сокращенно):
```python
# ИНЪЕКЦИЯ КОНТЕКСТА В GEMINI 3
def _get_or_create_history(self, user_id: int):
    if user_id not in self.user_histories:
        self.user_histories[user_id] = [
            types.Content(role="user", parts=[types.Part(text=self.system_instruction)]),
            types.Content(role="model", parts=[types.Part(text="Понял, я — ассистент компании «Этажи»...")])
        ]
    return self.user_histories[user_id]
```

---

## 2. Логика Уведомлений и RAG (Индексатор)
**Файл:** [GOOGLE_APPS_SCRIPT_FULL.js](file:///Users/verakoroleva/Desktop/marketingbot/GOOGLE_APPS_SCRIPT_FULL.js)

### Анализ:
*   **Конвертация ссылок:** Скрипт в Google Sheets автоматически находит ссылки на файлы Google Drive и превращает их в прямые ссылки `https://lh3.googleusercontent.com/d/[ID]`.
*   **Проблема Base64:** Скрипт пропускает строки `data:image/...` без изменений. Telegram API блокирует такие отправки, так как ожидает либо URL, либо FileID.

---

## 3. Обработка Сообщений
**Файл:** [handlers.py](file:///Users/verakoroleva/Desktop/marketingbot/handlers.py)

*   **Авторизация:** Интегрирована проверка через `auth_service` перед любым вызовом ИИ.
*   **Индикация:** Использование `send_chat_action(action="typing")` для UX во время ожидания ответа от Gemini 3 (которое может занимать 3-7 секунд из-за глубокого рассуждения модели).

---

## 4. Логи Сервера (Debug Dump)

### ✅ Успех (Работа Gemini 3 Pro):
```text
Jan 18 09:15:10 - ai_service - INFO - GeminiService is ready
Jan 18 09:15:50 - gemini_service - INFO - Sending request to Gemini for user 284355186 (history: 3 messages)
Jan 18 09:15:55 - gemini_service - INFO - Received response from Gemini for user 284355186: 450 chars
```

### ❌ Ошибка (Base64 в Акциях):
```text
Jan 18 09:15:24 - promotions_notifier - WARNING - Не удалось отправить уведомление пользователю 284355186: 
Wrong remote file identifier specified: wrong character in the string
```

---
**Документ подготовлен:** Antigravity AI
**Дата:** 18 января 2026 г.
