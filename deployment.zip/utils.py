import os
import logging
from urllib.parse import urlparse
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

logger = logging.getLogger(__name__)

def _validate_url(url: str) -> bool:
    """Проверяет, является ли строка валидным URL."""
    if not url:
        return False
    try:
        result = urlparse(url)
        return all([result.scheme, result.netloc])
    except Exception:
        return False

def get_web_app_url() -> str:
    """Ленивое чтение URL WebApp из окружения (после загрузки .env)."""
    base_url = os.getenv("WEB_APP_URL") or ""
    
    # Валидация URL
    if base_url and not _validate_url(base_url):
        logger.error(f"WEB_APP_URL содержит невалидный URL: {base_url}")
        return ""
    
    if base_url and not base_url.endswith('/'):
        base_url += '/'
    url = base_url + "index.html"
    logger.debug(f"Generated WebApp URL: {url}")
    return url

def get_spa_menu_url() -> str:
    """Ленивое чтение URL SPA меню из окружения."""
    base_url = os.getenv("WEB_APP_URL") or ""
    # Версия для принудительного обновления кеша WebApp
    cache_bust = "v=20260107-4"
    
    # Валидация URL
    if base_url and not _validate_url(base_url):
        logger.error(f"WEB_APP_URL содержит невалидный URL: {base_url}")
        return ""
    
    if base_url and not base_url.endswith('/'):
        base_url += '/'
    url = f"{base_url}menu.html?{cache_bust}"
    logger.debug(f"Generated SPA Menu URL: {url}")
    return url

def create_specialist_button() -> InlineKeyboardMarkup:
    """
    Создает инлайн-кнопку для обращения к специалисту.
    """
    keyboard = [[InlineKeyboardButton("👨‍💼 Обратиться к специалисту", callback_data="contact_specialist")]]
    return InlineKeyboardMarkup(keyboard)

def _is_user_escalation_request(text: str) -> bool:
    """
    Проверяет, содержит ли сообщение пользователя триггерные слова для эскалации.
    """
    import re
    
    # Нормализуем текст: убираем знаки препинания и приводим к нижнему регистру
    text_normalized = re.sub(r'[^\w\s]', '', text.lower())
    
    # Прямые триггерные фразы для эскалации (30 фраз)
    escalation_phrases = [
        'хочу поговорить со специалистом',
        'нужен специалист',
        'передайте специалисту',
        'соедините с менеджером',
        'соедините с специалистом',
        'хочу к человеку',
        'живой человек',
        'реальный специалист',
        'дайте мне специалиста',
        'дайте специалиста',
        'хочу специалиста',
        'нужен человек',
        'хочу к специалисту',
        'нужен маркетолог',
        'хочу маркетолога',
        'дайте маркетолога',
        'нужен специалист по маркетингу',
        'хочу специалиста по маркетингу',
        'дайте специалиста по маркетингу',
        'нужен специалист отдела маркетинга',
        'хочу специалиста отдела маркетинга',
        'дайте специалиста отдела маркетинга',
        'передайте мой вопрос',
        'передайте мою проблему',
        'передайте мое обращение',
        'эскалируйте вопрос',
        'эскалируйте проблему',
        'эскалируйте обращение',
        'хочу поговорить с человеком',
        'дайте человека'
    ]
    
    # Проверяем наличие триггерных фраз в нормализованном тексте
    for phrase in escalation_phrases:
        if phrase in text_normalized:
            return True
    
    return False

def _is_ai_asking_for_escalation(ai_response: str) -> bool:
    """
    Проверяет, спрашивает ли ИИ о необходимости передачи специалисту.
    """
    if not ai_response:
        return False
        
    response_lower = ai_response.lower()
    
    # Фразы, когда ИИ спрашивает об эскалации
    escalation_questions = [
        'нужно ли передать',
        'передать специалисту',
        'соединить со специалистом',
        'связать со специалистом',
        'передать ваш запрос',
        'передать вашу проблему',
        'передать ваше обращение',
        'эскалировать вопрос',
        'эскалировать проблему',
        'эскалировать обращение',
        'передать менеджеру',
        'соединить с менеджером',
        'связать с менеджером',
        'передать маркетологу',
        'соединить с маркетологом',
        'связать с маркетологом'
    ]
    
    # Проверяем наличие вопросов об эскалации
    for phrase in escalation_questions:
        if phrase in response_lower:
            return True
    
    return False

def _is_escalation_confirmation(text: str) -> bool:
    """
    Проверяет, содержит ли сообщение подтверждение эскалации к специалисту.
    """
    text_lower = text.lower()
    
    # Фразы подтверждения эскалации (когда ИИ спрашивает)
    confirmation_phrases = [
        'да',
        'да, нужно',
        'да, передайте',
        'да, соедините',
        'да, свяжите',
        'да, пожалуйста',
        'да, конечно',
        'да, давайте',
        'да, хорошо',
        'да, согласен',
        'нужно',
        'передайте',
        'соедините',
        'свяжите',
        'пожалуйста',
        'конечно',
        'давайте',
        'хорошо',
        'согласен',
        'подтверждаю'
    ]
    
    # Проверяем наличие фраз подтверждения
    for phrase in confirmation_phrases:
        if phrase in text_lower:
            return True
    
    return False

def _should_show_specialist_button(text: str) -> bool:
    """
    Проверяет, просит ли пользователь соединить его со специалистом/живым человеком.
    """
    text_lower = text.lower()
    
    # Ключевые фразы, которые указывают на желание поговорить со специалистом
    specialist_keywords = [
        'специалист', 'специалиста', 'специалисту', 'специалистом',
        'живой человек', 'живому человеку', 'живым человеком',
        'менеджер', 'менеджера', 'менеджеру', 'менеджером',
        'сотрудник', 'сотрудника', 'сотруднику', 'сотрудником',
        'оператор', 'оператора', 'оператору', 'оператором',
        'консультант', 'консультанта', 'консультанту', 'консультантом',
        'соединить', 'соедините', 'соедини', 'соединиться',
        'поговорить', 'поговорить с', 'поговорить с человеком',
        'человек', 'человека', 'человеку', 'человеком',
        'позвонить', 'позвоните', 'звонок', 'звонить',
        'связаться', 'связаться с', 'связать', 'связать с',
        'поддержка', 'поддержку', 'поддержке', 'поддержкой',
        'помощь', 'помощи', 'помочь', 'помощью',
        'не могу', 'не получается', 'не работает',
        'проблема', 'проблемы', 'проблему', 'проблемой',
        'сложно', 'сложный', 'сложная', 'сложное',
        'не понимаю', 'не понятно', 'не ясно',
        'объясните', 'объясни', 'объяснить',
        'подробнее', 'подробно', 'подробный',
        'детали', 'детализация', 'детально'
    ]
    
    # Проверяем наличие ключевых слов
    for keyword in specialist_keywords:
        if keyword in text_lower:
            return True
    
    return False
