#!/bin/bash
# Скрипт для безопасного деплоя на сервер с проверками
# Гарантирует, что тестируется только серверная версия бота

set -e

echo "🔍 Проверка перед деплоем..."
echo ""

# 1. Проверка отсутствия локальных процессов бота
echo "1️⃣ Проверка отсутствия локальных процессов bot.py..."
if ps aux | grep 'python.*bot\.py' | grep -v grep > /dev/null 2>&1; then
    echo "❌ ОШИБКА: Обнаружен локальный процесс bot.py!"
    echo ""
    echo "Запущенные процессы:"
    ps aux | grep 'python.*bot\.py' | grep -v grep
    echo ""
    echo "⚠️  ОСТАНОВИТЕ локальный процесс перед деплоем!"
    echo "Команда: pkill -f 'python.*bot\.py'"
    exit 1
fi
echo "✅ Локальные процессы не найдены"
echo ""

# 2. Проверка наличия несохраненных изменений
echo "2️⃣ Проверка Git статуса..."
if ! git diff-index --quiet HEAD --; then
    echo "⚠️  Обнаружены несохраненные изменения!"
    git status --short
    read -p "Продолжить деплой? (y/n): " -n 1 -r
    echo ""
    if [[ ! $REPLY =~ ^[Yy]$ ]]; then
        echo "Деплой отменен"
        exit 1
    fi
fi
echo "✅ Git статус проверен"
echo ""

# 3. Пуш изменений в GitHub
echo "3️⃣ Пуш изменений в GitHub..."
git push origin main || {
    echo "❌ Ошибка при пуше в GitHub"
    exit 1
}
echo "✅ Изменения запушены"
echo ""

# 4. Деплой на сервер
echo "4️⃣ Деплой на сервер Yandex Cloud..."
SERVER_USER="ubuntu"
SERVER_HOST="84.252.137.116"
SSH_KEY="$HOME/.ssh/ssh-key-1767684261599/ssh-key-1767684261599"

ssh -i "$SSH_KEY" "${SERVER_USER}@${SERVER_HOST}" << 'ENDSSH'
cd /home/ubuntu/marketingbot
echo "Обновление кода..."
git pull
echo "Обновление зависимостей..."
/home/ubuntu/marketingbot/.venv/bin/pip install -r requirements.txt
echo "Перезапуск бота..."
sudo systemctl restart marketingbot-bot.service
echo "Ожидание запуска..."
sleep 2
ENDSSH

echo "✅ Деплой завершен"
echo ""

# 5. Проверка статуса на сервере
echo "5️⃣ Проверка статуса бота на сервере..."
ssh -i "$SSH_KEY" "${SERVER_USER}@${SERVER_HOST}" \
    "sudo systemctl status marketingbot-bot.service | head -20"
echo ""

echo "✅ Деплой успешно завершен!"
echo ""
echo "📱 Теперь можно тестировать бота через Telegram"
echo "📊 Просмотр логов: ssh -i $SSH_KEY ${SERVER_USER}@${SERVER_HOST} 'journalctl -u marketingbot-bot.service -f'"
