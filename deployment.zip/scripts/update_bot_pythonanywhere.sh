#!/bin/bash

# Скрипт для обновления и перезапуска бота на PythonAnywhere
echo "🔄 Обновление MarketingBot на PythonAnywhere..."

# Определяем путь к проекту
PROJECT_DIR="$HOME/marketing"
cd "$PROJECT_DIR" || exit 1

# Останавливаем текущий бот
echo "⏹️ Остановка текущего бота..."
pkill -f "python.*bot.py" 2>/dev/null && echo "✅ Бот остановлен" || echo "ℹ️ Бот не был запущен"

# Небольшая задержка для завершения процессов
sleep 2

# Обновляем код из GitHub
echo "📥 Обновление кода из GitHub..."
git fetch origin
git pull origin main

if [ $? -eq 0 ]; then
    echo "✅ Код успешно обновлен"
else
    echo "❌ Ошибка при обновлении кода из GitHub"
    exit 1
fi

# Проверяем зависимости (опционально, если нужно обновить)
echo "🔍 Проверка зависимостей..."
if command -v python3.10 &> /dev/null; then
    PYTHON_CMD="python3.10"
elif command -v python3 &> /dev/null; then
    PYTHON_CMD="python3"
else
    echo "❌ Ошибка: Python не найден!"
    exit 1
fi

# Запускаем обновленный бот
echo "▶️ Запуск обновленного бота..."
nohup $PYTHON_CMD bot.py > bot.log 2>&1 &

# Ждем немного
sleep 3

# Проверяем, что процесс запущен
if pgrep -f "python.*bot.py" > /dev/null; then
    echo "✅ Бот успешно запущен!"
    echo ""
    echo "📋 Полезные команды:"
    echo "  Просмотр логов: tail -f bot.log"
    echo "  Проверка процесса: ps aux | grep python | grep bot"
    echo "  Остановка бота: pkill -f 'python.*bot.py'"
else
    echo "❌ Ошибка: Бот не запустился!"
    echo "Проверьте логи: tail -20 bot.log"
    exit 1
fi
