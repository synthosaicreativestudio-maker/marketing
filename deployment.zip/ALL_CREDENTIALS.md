# 🔐 Все доступы, настройки и пароли

**Дата:** 18 января 2026  
**Важно:** Этот документ содержит конфиденциальную информацию. Храните его в безопасности!

---

## 🖥️ Сервер

### Основные данные сервера:
- **IP адрес:** `37.1.212.51`
- **Операционная система:** Ubuntu 22.04.4 LTS
- **Ядро:** Linux 5.15.0-101-generic
- **Архитектура:** x86_64
- **Расположение:** VPS, США

### SSH доступ:
- **Адрес:** `root@37.1.212.51`
- **Пользователь:** `root`
- **Пароль:** `LEJ6U5chSK`
- **Порт:** `22` (стандартный)

**Команда подключения:**
```bash
ssh root@37.1.212.51
```

---

## 🔒 TinyProxy (HTTP Прокси)

### Основные параметры:
- **Хост:** `37.1.212.51`
- **Порт:** `8080`
- **Протокол:** HTTP
- **Логин:** `root`
- **Пароль:** `LEJ6U5chSK`

### Полный URL прокси:
```
http://root:LEJ6U5chSK@37.1.212.51:8080
```

### Переменные окружения для `.env`:
```bash
# OpenAI Proxy Configuration
OPENAI_PROXY_URL=http://root:LEJ6U5chSK@37.1.212.51:8080
HTTP_PROXY=http://37.1.212.51:8080
HTTPS_PROXY=http://37.1.212.51:8080
NO_PROXY=127.0.0.1,localhost,10.129.0.24
```

### Назначение:
- HTTP прокси для обхода региональных ограничений при доступе к OpenAI API
- Используется для MarketingBot проекта
- Работает как системный сервис

### Проверка работы:
```bash
curl -x http://root:LEJ6U5chSK@37.1.212.51:8080 https://api.openai.com/v1/models
```

---

## 🌐 Marzban (VPN панель управления)

### Доступ к панели Marzban:
- **Порт:** `8000`
- **Слушает на:** `127.0.0.1:8000` (только localhost)
- **Прямой доступ:** ❌ Невозможен (порт привязан к localhost)

### SSH туннель для доступа (рекомендуется):
```bash
ssh -L 8000:127.0.0.1:8000 root@37.1.212.51
```

Затем откройте в браузере:
```
http://localhost:8000
```

### Альтернатива - прямой доступ (требует настройки):
1. Изменить `.env` файл Marzban на сервере:
   ```bash
   UVICORN_HOST = "0.0.0.0"
   UVICORN_PORT = 8000
   ```
2. Открыть порт в файрволе:
   ```bash
   ufw allow 8000/tcp
   ```
3. Затем доступ по адресу: `http://37.1.212.51:8000`

### Создание первого администратора:
```bash
ssh root@37.1.212.51
cd /opt/marzban
docker compose exec marzban marzban cli admin create
```

### Расположение на сервере:
- **Конфигурация:** `/opt/marzban/`
  - `docker-compose.yml`
  - `.env`
- **Данные:** `/var/lib/marzban/`
  - `xray_config.json`
  - `db.sqlite3`

---

## 🔐 VLESS + REALITY VPN

### Настройки протокола:
- **Протокол:** VLESS
- **Безопасность:** REALITY
- **Порт:** `443`
- **Flow:** `xtls-rprx-vision`
- **Маскировка под:** `www.microsoft.com:443`

### Ключи REALITY (x25519):
- **Private Key:** `4PjME9JBUmV-Td9rZGS9l0147TXqMJtcU_f2iG-PVxA`
- **Public Key:** `n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4`

### Параметры маскировки:
- **SNI (Server Name):** `www.microsoft.com`
- **Destination:** `www.microsoft.com:443`
- **Fingerprint:** `chrome`
- **Short IDs:** `[""]` (пустой)

### UUID пользователя:
```
eb4a1cf2-4235-4b0a-83b2-0e5a298389ed
```

### Ссылка для подключения:
```
vless://eb4a1cf2-4235-4b0a-83b2-0e5a298389ed@37.1.212.51:443?type=tcp&security=reality&sni=www.microsoft.com&pbk=n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4&fp=chrome&flow=xtls-rprx-vision#VLESS-Reality
```

### Параметры ссылки:
| Параметр | Значение |
|----------|----------|
| Протокол | vless |
| UUID | eb4a1cf2-4235-4b0a-83b2-0e5a298389ed |
| Сервер | 37.1.212.51 |
| Порт | 443 |
| Тип | tcp |
| Безопасность | reality |
| SNI | www.microsoft.com |
| Public Key | n5E8KcFHjef-ZC2mKjzkVldLJiLrsjfpE1Z-XmLfxH4 |
| Fingerprint | chrome |
| Flow | xtls-rprx-vision |

---

## 🔌 Открытые порты на сервере

| Порт | Протокол | Сервис | Статус файрвола | Описание |
|------|----------|--------|-----------------|----------|
| **22** | TCP | SSH | ✅ Открыт | Удаленное управление сервером |
| **443** | TCP | VLESS + REALITY | ✅ Открыт | VPN подключения |
| **8080** | TCP | TinyProxy | ✅ Открыт | HTTP прокси для OpenAI API |
| **8000** | TCP | Marzban Web UI | ✅ Открыт | Панель управления (localhost) |
| **1080** | TCP | Shadowsocks | 🔒 Закрыт | Альтернативный протокол |
| **31338** | TCP | Xray API | 🔒 Закрыт | Внутренний API Xray (localhost) |
| **44455** | UDP | Amnezia AWG | ✅ Открыт | Существующий VPN сервис |
| **49576** | UDP | Amnezia WireGuard | ✅ Открыт | Существующий VPN сервис |

---

## 🐳 Docker контейнеры

### 1. Marzban (VPN панель)
- **Контейнер:** `marzban-marzban-1`
- **Образ:** `gozargah/marzban:latest`
- **Статус:** Running
- **Сеть:** host mode
- **Volumes:**
  - `/var/lib/marzban:/var/lib/marzban`
  - `/opt/marzban/.env`

### 2. Amnezia WireGuard
- **Контейнер:** `amnezia-wireguard`
- **Порты:** `0.0.0.0:49576->49576/udp`
- **Статус:** Running

### 3. Amnezia AWG
- **Контейнер:** `amnezia-awg`
- **Порты:** `0.0.0.0:44455->44455/udp`
- **Статус:** Running

---

## 🛡️ Файрвол (UFW)

### Статус:
- **Активен:** ✅ Да
- **Политика по умолчанию:** Deny (запрещено по умолчанию)

### Открытые порты:
```bash
22/tcp      # SSH
443/tcp     # VLESS + REALITY VPN
8080/tcp    # TinyProxy
8000/tcp    # Marzban Web UI
62050-62053/tcp  # Marzban (резерв)
```

### Команды управления файрволом:
```bash
# Проверить статус
sudo ufw status

# Открыть порт
sudo ufw allow 443/tcp

# Закрыть порт
sudo ufw delete allow 443/tcp

# Перезапустить файрвол
sudo ufw reload
```

---

## 🔧 Установленное ПО

- **Docker:** 29.1.4
- **Docker Compose:** Установлен
- **Marzban:** gozargah/marzban:latest
- **Xray Core:** 24.12.31
- **TinyProxy:** Системный сервис

---

## 📋 Полезные команды

### Управление Marzban:
```bash
# Проверить статус контейнера
docker ps | grep marzban

# Просмотреть логи
docker logs marzban-marzban-1 --tail 50

# Перезапустить Marzban
cd /opt/marzban
docker compose restart

# Просмотреть конфигурацию Xray
cat /var/lib/marzban/xray_config.json | python3 -m json.tool

# Создать администратора
docker compose exec marzban marzban cli admin create
```

### Проверка портов:
```bash
# Проверить кто слушает порт 443
netstat -tlnp | grep 443

# Проверить все открытые порты
ss -tulnp
```

### Управление TinyProxy:
```bash
# Проверить статус
systemctl status tinyproxy

# Перезапустить
systemctl restart tinyproxy

# Просмотреть логи
tail -f /var/log/tinyproxy/tinyproxy.log
```

---

## 📱 Клиенты для подключения

### Совместимые приложения:
- ✅ **Amnezia VPN** (рекомендуется)
- ✅ **v2rayNG** (Android)
- ✅ **Shadowrocket** (iOS)
- ✅ **V2RayN** (Windows)
- ✅ **Qv2ray** (Linux, Windows, macOS)
- ✅ **Clash Meta** (Windows, macOS, Android)

### Инструкция подключения:
1. Скопируйте ссылку `vless://...`
2. Откройте клиент VPN
3. Добавить сервер → Из буфера обмена
4. Вставьте ссылку
5. Подключитесь

---

## 🔐 Безопасность

### Реализованные меры:
- ✅ REALITY маскировка под Microsoft
- ✅ Flow xtls-rprx-vision для обхода DPI
- ✅ Файрвол настроен (открыты только необходимые порты)
- ✅ SSH доступ только по паролю (рекомендуется настроить SSH ключи)

### Рекомендации:
1. **Не делитесь** этим документом публично
2. **Храните** пароли в безопасном месте (например, в менеджере паролей)
3. **Настройте** SSH ключи вместо паролей для большей безопасности
4. **Регулярно обновляйте** систему и Docker образы
5. **Создайте резервные копии** конфигурации

---

## 📁 Важные файлы

### На вашем компьютере:
- **vless_connection_link.txt** - Ссылка для подключения
- **generated_config.json** - Конфигурация с ключами
- **PROXY_SETTINGS.md** - Документация по прокси
- **SERVER_CONFIGURATION_REPORT.md** - Полный технический отчет

### На сервере:
- `/var/lib/marzban/xray_config.json` - Конфигурация Xray
- `/opt/marzban/docker-compose.yml` - Docker Compose файл
- `/opt/marzban/.env` - Переменные окружения Marzban
- `/etc/tinyproxy/tinyproxy.conf` - Конфигурация TinyProxy

---

## 📊 Резервное копирование

### Что нужно сохранять:
1. **Ключи REALITY** (Private и Public)
2. **UUID пользователя**
3. **Конфигурация Xray** (`/var/lib/marzban/xray_config.json`)
4. **База данных Marzban** (`/var/lib/marzban/db.sqlite3`)
5. **Этот документ** (ALL_CREDENTIALS.md)

### Команды для бэкапа:
```bash
# Скопировать конфигурацию Xray
scp root@37.1.212.51:/var/lib/marzban/xray_config.json ~/backup/

# Скопировать базу данных
scp root@37.1.212.51:/var/lib/marzban/db.sqlite3 ~/backup/

# Создать архив всех данных Marzban
ssh root@37.1.212.51 "tar -czf /tmp/marzban_backup.tar.gz /var/lib/marzban/"
scp root@37.1.212.51:/tmp/marzban_backup.tar.gz ~/backup/
```

---

## ⚠️ Важные замечания

1. **TinyProxy на порту 8080** - работает как раньше, используется для MarketingBot
2. **VLESS + REALITY на порту 443** - новый VPN сервер
3. **Существующие Amnezia сервисы** - не были затронуты при настройке
4. **Данные прокси** - содержат чувствительную информацию, файл `.env` НЕ коммитится в Git

---

## 🆘 Контакты и поддержка

### При проблемах с доступом:
1. Проверьте файрвол: `sudo ufw status`
2. Проверьте статус сервисов: `docker ps`
3. Просмотрите логи: `docker logs marzban-marzban-1 --tail 50`
4. Перезапустите сервисы: `cd /opt/marzban && docker compose restart`

### Проверка TinyProxy:
```bash
curl -x http://root:LEJ6U5chSK@37.1.212.51:8080 https://api.openai.com/v1/models
```

### Проверка VLESS:
Используйте любой совместимый клиент с ссылкой подключения.

---

**Создано:** 18 января 2026  
**Статус:** ✅ Все сервисы работают  
**Важно:** Храните этот файл в безопасности! 🔐
