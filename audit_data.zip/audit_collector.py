import os

# Игнорируем мусор, виртуальное окружение и статику
IGNORE_DIRS = {
    '.git', '.venv', 'venv', 'env', '__pycache__', '.idea', '.vscode', 
    '__MACOSX', 'node_modules', 'media', 'static', 'build', 'dist'
}

# Игнорируем бинарные файлы и картинки
IGNORE_EXTENSIONS = {
    '.pyc', '.png', '.jpg', '.jpeg', '.gif', '.ico', '.zip', '.tar', '.gz', 
    '.db', '.sqlite', '.pdf', '.docx', '.xlsx'
}

# Файлы с секретами (фиксируем наличие, но скрываем содержимое)
SECRET_FILES = {'.env', 'config.py', 'secrets.py', 'credentials.json'}

OUTPUT_FILE = 'full_audit_dump.txt'

def collect_audit_data():
    with open(OUTPUT_FILE, 'w', encoding='utf-8') as out:
        out.write("=== 1. PROJECT FILE STRUCTURE ===\n")
        
        # 1. Дерево файлов
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
            level = root.replace('.', '').count(os.sep)
            indent = ' ' * 4 * level
            out.write(f"{indent}[DIR] {os.path.basename(root)}/\n")
            subindent = ' ' * 4 * (level + 1)
            for f in files:
                if not any(f.endswith(ext) for ext in IGNORE_EXTENSIONS):
                    file_path = os.path.join(root, f)
                    try:
                        file_size = os.path.getsize(file_path) / 1024  # KB
                        out.write(f"{subindent}{f} ({file_size:.1f} KB)\n")
                    except OSError:
                        out.write(f"{subindent}{f} (Error getting size)\n")

        out.write("\n\n=== 2. FILE CONTENTS ===\n")

        # 2. Содержимое файлов
        for root, dirs, files in os.walk('.'):
            dirs[:] = [d for d in dirs if d not in IGNORE_DIRS]
            
            for file in files:
                if any(file.endswith(ext) for ext in IGNORE_EXTENSIONS):
                    continue
                
                file_path = os.path.join(root, file)
                if file in [OUTPUT_FILE, 'audit_collector.py', 'collect_code.py']:
                    continue

                out.write(f"\n{'='*20} START FILE: {file_path} {'='*20}\n")
                
                if file in SECRET_FILES:
                    out.write("[CONTENT HIDDEN - SECRET FILE]\n")
                else:
                    try:
                        if os.path.getsize(file_path) > 500 * 1024: 
                            out.write("[CONTENT SKIPPED - FILE TOO LARGE]\n")
                            continue
                        with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                            out.write(f.read())
                    except Exception as e:
                        out.write(f"[ERROR READING FILE: {e}]\n")
                
                out.write(f"\n{'='*20} END FILE: {file_path} {'='*20}\n")

    print(f"✅ Dump created: {OUTPUT_FILE}")

if __name__ == '__main__':
    collect_audit_data()
